# Movie-Recommender-System

Build a movie recommender system based on Item-Item collaborative filtering using grouplens.org Movies datasets. The total number of movie Data in a Dataset is 100K. 
Item-based techniques first analyze the user-item matrix to identify relationships between different items, and then use these relationships to indirectly compute recommendations for users.This project coded in python and using python Pandas library for Data Analysis. 

Dataset Source: <a href="http://grouplens.org/datasets/movielens/">GroupLens</a>
